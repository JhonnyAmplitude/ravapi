#!/bin/bash
# Для установки Java
sudo apt install openjdk-8-jdk-headless
sudo apt install openjdk-8-jre-headless
# Создание пользователя системы для работы с HADOOP
sudo addgroup hadoop
sudo adduser --ingroup hadoop hduser
sudo usermod -a -G sudo hduser﻿
# Установка SSH-сервера:
sudo apt-get install openssh-server
# Далее зайти под пользователем hduser и сгенерировать SSH-ключи.
sudo su hduser
ssh-keygen -t rsa -P ""
cat $HOME/.ssh/id_rsa.pub >> $HOME/.ssh/authorized_keys
# Download hadoop
sudo wget http://apache-mirror.rbc.ru/pub/apache/hadoop/common/hadoop-2.10.1/hadoop-2.10.1.tar.gz
sudo tar -xzvf hadoop-2.10.1.tar.gz
sudo mv hadoop-2.10.1 /usr/local/hadoop/hadoop-2.10.1
# Создадим рабочие каталоги для HDFS и назначим владельца каталога hadoop (пользователь hduser):
sudo mkdir -p /usr/local/hadoop/hadoop_tmp/hdfs/namenode
sudo mkdir -p /usr/local/hadoop/hadoop_tmp/hdfs/datanode
sudo chown hduser:hadoop -R /usr/local/hadoop/
cd
sudo cp /home/ravil/sh-hadoop/move/.bashrc /home/hduser/
sudo cp /home/ravil/sh-hadoop/move/hadoop-env.sh /usr/local/hadoop/hadoop-2.10.1/etc/hadoop
sudo cp /home/ravil/sh-hadoop/move/core-site.xml /usr/local/hadoop/hadoop-2.10.1/etc/hadoop
sudo cp /home/ravil/sh-hadoop/move/hdfs-site.xml /usr/local/hadoop/hadoop-2.10.1/etc/hadoop
sudo cp /home/ravil/sh-hadoop/move/yarn-site.xml /usr/local/hadoop/hadoop-2.10.1/etc/hadoop
sudo cp /home/ravil/sh-hadoop/move/mapred-site.xml /usr/local/hadoop/hadoop-2.10.1/etc/hadoop
sudo reboot



