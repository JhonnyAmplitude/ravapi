#!/bin/bash
sudo su hduser
cd
# Master
sudo gedit /etc/hostname
# Добавить пользователей и их ip (192.168.2.1 Master)
sudo gedit /etc/hosts
# Установить утилиту rsync
sudo apt-get install rsync
# Написать имя мастера (Master)
sudo gedit masters
# Прописываем там все подчиненные машины (Master 1VM 2VM через Enter)
sudo gedit slaves
#
sudo rm -rf /usr/local/hadoop/hadoop_tmp/
sudo mkdir -p /usr/local/hadoop/hadoop_tmp/hdfs/namenode
sudo mkdir -p /usr/local/hadoop/hadoop_tmp/hdfs/datanode
sudo chown hduser:hadoop -R /usr/local/hadoop/hadoop_tmp/
sudo chown hduser:hadoop -R /usr/local/hadoop/


