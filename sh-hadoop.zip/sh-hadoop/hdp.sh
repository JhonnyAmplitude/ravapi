#!/bin/bash
/usr/local/hadoop/hadoop-2.10.1/sbin/start-dfs.sh
/usr/local/hadoop/hadoop-2.10.1/sbin/start-yarn.sh

