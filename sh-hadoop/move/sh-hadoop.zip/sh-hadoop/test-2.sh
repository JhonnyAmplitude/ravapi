#!/bin/bash
sudo su hduser
cd
# Master
sudo nano /etc/hostname
# Добавить пользователей и их ip (192.168.2.1 Master)
sudo nano /etc/hosts
# Установить утилиту rsync
sudo apt-get install rsync
# Написать имя мастера (Master)
sudo nano masters
# Прописываем там все подчиненные машины (Master 1VM 2VM через Enter)
sudo nano slaves


