#!/bin/bash
sudo rm -rf /usr/local/hadoop/hadoop_tmp/
sudo mkdir -p /usr/local/hadoop/hadoop_tmp/hdfs/namenode
sudo mkdir -p /usr/local/hadoop/hadoop_tmp/hdfs/datanode
sudo chown hduser:hadoop -R /usr/local/hadoop/hadoop_tmp/
sudo chown hduser:hadoop -R /usr/local/hadoop/


